package com.example.product_crud.rest;

public class RestAplication {

}
