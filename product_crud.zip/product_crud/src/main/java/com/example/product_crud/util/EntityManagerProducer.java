package com.example.product_crud.util;

public class EntityManagerProducer {

}
